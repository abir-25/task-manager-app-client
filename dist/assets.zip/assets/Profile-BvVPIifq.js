import{j as r}from"./index-BGeUDN-j.js";const e=()=>r.jsx("div",{children:"Profile"});export{e as Profile};
